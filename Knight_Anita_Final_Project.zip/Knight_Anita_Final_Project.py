"""
Program: Knight_Anita_Final_Project  Federal income tax estimator app
Author: Anita Knight
Last date modified: 03/14/2022

The purpose of this program is to provide  able to provide a reasonable
estimate of federal taxes owed for a simple tax return.
The following entries are made:
        Filing status
	Income types: wages, social security ,retirement, interest/dividends
	Adjustments to income: IRA or retirement contributions
	Taxes withheld
	Checkboxes for taxpayer/spouse over 65
	Checkboxes for taxpayer/spouse who is blind
	Optional entry for itemized deductions

Basic logic:

    tkinter window is built with appropriate widgets
    EnterItemized is called if user pressed "enter itemized" button
    ProcessInput function is called when user presses "calculate tax" button
        Validate input- validation of all user entries
        Display results
            calls to functions to calculate datapoints:
                CalcTotalIncome -- sums 4 income tyipes
                CalcAdjIncome --(AGI) reduces income by any adjustments entered
                CalcStandDed  -- uses constant values to determine standard
                                deduction
                CalcItemDed  -- computes itemized deduction; if user did not
                                enter any data, will be zero
                CalcTaxableInc -- reduces AGI by larger of the two deductions
                CalcTax  -- uses constant values to determine the total tax
            sets up window to display all the resulting datapoints
    

"""
import tkinter as tk
from tkinter import *
from tkinter import messagebox


#   ProcessInput is called when user pressed Calc Est Tax button
def ProcessInput():
    ValidateInput()   # make sure all input fields are valid
    DisplayResults()   # if all input is valid, display the results

def ValidateInput():
    #
    #  only Filing Status is required; all other fields can be left blank
    #  if numeric field is blank, program assumes it is zero

    var = fStat.get()
    if var == " ":
        messagebox.showerror("Input error", "Filing status is required")

    var = entWages.get()
    if len(var)!=0:
        try:
            var = float(entWages.get())
           
        except ValueError:
            messagebox.showerror("Input error", "All fields must be numeric")
    else:
        entWages.insert(0,string="0")
                   
    var = entIntDiv.get()
    if len(var) != 0:
        try:
            var = float(entIntDiv.get())

        except ValueError:
            messagebox.showerror("Input error", "All fields must be numeric")
    else:
        entIntDiv.insert(0,string="0")

    var = entSocSec.get()
    if len(var) != 0:
        try:
            var = float(entSocSec.get())

        except ValueError:
            messagebox.showerror("Input error", "All fields must be numeric")
    else:
        entSocSec.insert(0,string="0")

    var = entRetire.get()
    if len(var) != 0:
        try:
            var = float(entRetire.get())

        except ValueError:
            messagebox.showerror("Input error", "All fields must be numeric")
    else:
        entRetire.insert(0,string="0")

    var = entIRAAdj.get()
    if len(var) != 0:
        try:
            var = float(entIRAAdj.get())

        except ValueError:
            messagebox.showerror("Input error", "All fields must be numeric")
    else:
        entIRAAdj.insert(0,string="0")

    var = entRetireAdj.get()
    if len(var) != 0:
        try:
            var = float(entRetireAdj.get())

        except ValueError:
            messagebox.showerror("Input error", "All fields must be numeric")
    else:
        entRetireAdj.insert(0,string="0")

    var = entTaxWH.get()
    if len(var) != 0:
        try:
            var = float(entTaxWH.get())

        except ValueError:
            messagebox.showerror("Input error", "All fields must be numeric")
    else:
        entTaxWH.insert(0,string="0")


    EnableItemized()
    var = entTaxPd.get()
    if len(var) != 0:
        try:
            var = float(entTaxPd.get())

        except ValueError:
            messagebox.showerror("Input error", "All fields must be numeric")
    else:
        entTaxPd.insert(0,string="0")

    var = entMedExp.get()
    if len(var) != 0:
        try:
            var = float(entMedExp.get())

        except ValueError:
            messagebox.showerror("Input error", "All fields must be numeric")
    else:
        entMedExp.insert(0,string="0")

    var = entGiftChar.get()
    if len(var) != 0:
        try:
            var = float(entGiftChar.get())

        except ValueError:
            messagebox.showerror("Input error", "All fields must be numeric")
    else:
        entGiftChar.insert(0,string="0")

    var = entIntPd.get()
    if len(var) != 0:
        try:
            var = float(entIntPd.get())

        except ValueError:
            messagebox.showerror("Input error", "All fields must be numeric")
    else:
        entIntPd.insert(0,string="0")

    DisableItemized()


"""
  Set up the second window to display results

"""
def DisplayResults():

    fileStatus = fStat.get()

    totIncome = CalcTotalIncome()    # total income = sum of user entered income fields
    adjGrossIncome = CalcAdjIncome(totIncome)  # adjusted grosss deducts adjustments
    standDeduction = CalcStandDed(fileStatus)   # standard deduction
    itemDeduction = CalcItemDed(adjGrossIncome)  # itemized deductions
    if standDeduction >= itemDeduction:
         deductions = standDeduction
         typeDed = "Standard was better"
    else:
        deductions = itemDeduction
        typeDed = "Itemized was better"
        
    taxableIncome = CalcTaxableIncome(adjGrossIncome, deductions)  #taxable income

    totTax = CalcTax(fileStatus, taxableIncome)  # total tax
    taxDue = totTax - int(entTaxWH.get())    # tax that will be due 

 #   format fields to be displayed   
    formattedTotIncome = "{:,}".format(int(totIncome))
    formattedAdjIncome = "{:,}".format(int(adjGrossIncome))
    formattedDeductions = "{:,}".format(int(deductions))
    formattedTaxableIncome = "{:,}".format(int(taxableIncome))
    formattedTotTax = "{:,}".format(int(totTax))
    formattedWHeld = "{:,}".format(int(entTaxWH.get()))
    
    formattedTotTax = "{:,}".format(int(totTax))
    formattedTaxDue = "{:,}".format(int(taxDue))

#  set up window to display results
    resultsWindow=tk.Tk()
    resultsWindow.title("Your tax estimates")
    resultsWindow.geometry('500x500')
    resultsWindow.resizable(width=False, height = False)
    frmResults=tk.LabelFrame(resultsWindow, text="Calculated estimated tax", padx=10, pady=10)
    frmResults.grid(row=0, column=0, padx=20, pady=10)
    lblResults1=tk.Label(frmResults, text = "Total income: " + formattedTotIncome)

#  load formatted fields into labels for display
    lblResults2=tk.Label(frmResults, text = "Adjusted gross income: " + formattedAdjIncome)
    lblResults3=tk.Label(frmResults, text = "less Deductions: " + formattedDeductions)
    lblResults4=tk.Label(frmResults, text = typeDed)
    lblResults5=tk.Label(frmResults, text =  "Taxable income: " + formattedTaxableIncome)
    lblResults6=tk.Label(frmResults, text = "Total tax: " + formattedTotTax)
    lblResults7=tk.Label(frmResults, text = "Total withholdings to date: " + formattedWHeld)
    lblResults8=tk.Label(frmResults, text = "Estimated amount you will owe: " + formattedTaxDue)

#   position the labels on the grid
    lblResults1.grid(row=0,column=0,padx=20,pady=10, sticky = "E")
    lblResults2.grid(row=1,column=0,padx=20,pady=10, sticky = "E")
    lblResults3.grid(row=2,column=0,padx=20,pady=10, sticky = "E")
    lblResults4.grid(row=2,column=1,padx=20,pady=10, sticky = "E")
    lblResults5.grid(row=3,column=0,padx=20,pady=10, sticky = "E")
    lblResults6.grid(row=4,column=0,padx=20,pady=10, sticky = "E")
    lblResults7.grid(row=5,column=0,padx=20,pady=10, sticky = "E")
    lblResults8.grid(row=5,column=0,padx=20,pady=10, sticky = "E")


def EnterItemized():
#   Enter Itemized button has been pressed so those fields are activated

    EnableItemized()
    entTaxPd.grid(row=2, column =1, pady=10, sticky="NSEW")
    entMedExp.grid(row=3, column =1, sticky="NSEW")
    entGiftChar.grid(row=4, column =1, sticky="NSEW")
    entIntPd.grid(row=5, column =1, sticky="NSEW")

def EnableItemized():
    # change state to normal for entry
    entTaxPd.config(state=NORMAL)
    entMedExp.config(state=NORMAL)
    entGiftChar.config(state=NORMAL)
    entIntPd.config(state=NORMAL)

def DisableItemized():
    # change state to disabled to disallow entry
    entTaxPd.config(state=DISABLED)
    entMedExp.config(state=DISABLED)
    entGiftChar.config(state=DISABLED)
    entIntPd.config(state=DISABLED)
        
def CalcTotalIncome():
    # Total income is sum of any income fields that are populated
    totIncome = round(float(entWages.get()),0) + \
                round(float(entIntDiv.get()),0) + \
                round(float(entSocSec.get()),0) + \
                round(float(entRetire.get()),0)
    return totIncome

def CalcAdjIncome(totIncome):
    #  adjustments to income are subtracted
    adjGrossIncome = totIncome - \
                     round(float(entIRAAdj.get()),0) - \
                     round(float(entRetireAdj.get()),0)
    return adjGrossIncome

def CalcItemDed(adjGrossIncome):
    #  itemized deductions
    #  medical expenses are limited to percentage of adjusted gross income
    #  otherwise, it is he sum of entries entered
    
    MED_EXP_FLOOR = .075
    
    totItemizedDed = round(float(0.00),0)   # itemized deductions total

    totMedExp = round(float(entMedExp.get()),0)

    if totMedExp > (adjGrossIncome * MED_EXP_FLOOR):
        medExpDeduction = totMedExp - (adjGrossIncome * MED_EXP_FLOOR)
    else:
        medExpDeduction = 0

    totItemizedDed = round(float(entTaxPd.get()),0) + \
                round(float(entGiftChar.get()),0) + \
                round(float(entIntPd.get()),0) + \
                medExpDeduction

    return totItemizedDed


def CalcStandDed(fileStatus):
    #
    #  Calculate standard deduction; depends on filing status
    #
    #  Amount can be increased for special situations, over 65 or blind
    
    #  2 dimensional tuple for standrd deductions- current for tax year 2022
    STD_DEDUCTION = (("Single", 12950),("Married-Sep", 12950),
                     ("Married-Joint", 25900), ("Head House", 19400))

    #  Add on deduction amounts-- over 65- taxpayer or spouse
    STD_OVER_65_ADD_MARRIED_JOINT = 1400
    STD_OVER_65_ADD_ALL_OTHER = 1750

    #  Add on deduction amounts-- blind -taxpayer or spouse
    STD_BLIND_ADD_MARRIED_JOINT = 1400
    STD_BLIND_ADD_ALL_OTHER = 1750

    CHECKBOX_ON = 1
    
    standDeduction = 0        # standard deduction
    numStat = len(STD_DEDUCTION)
    for n in range(numStat):
        if fileStatus == STD_DEDUCTION[n][0]:
            standDeduction = STD_DEDUCTION[n][1]

#       Over 65 or blind means that standard deduction is increased
#
    if seniorTax.get() == CHECKBOX_ON:
        if fileStatus == "Married-Joint":
            standDeduction += STD_OVER_65_ADD_MARRIED_JOINT
        else:
            standDeduction += STD_OVER_65_ADD_ALL_OTHER
            
#     only option for when spouse is over 65 is married/joint, otherwise it doesn't apply
    if seniorSpouse.get() == CHECKBOX_ON:
        if fileStatus == "Married-Joint":
            standDeduction += STD_OVER_65_ADD_MARRIED_JOINT

    if blindTax.get() == CHECKBOX_ON:
        if fileStatus == "Married-Joint":
            standDeduction += STD_BLIND_ADD_MARRIED_JOINT
        else:
            standDeduction += STD_BLIND_ADD_ALL_OTHER

#     only option for when spouse is over 65 is married/joint, otherwise it doesn't apply
    if blindSpouse.get() == CHECKBOX_ON:
        if fileStatus == "Married-Joint":
            standDeduction += STD_BLIND_ADD_MARRIED_JOINT
            
    return standDeduction

def CalcTaxableIncome(adjGrossIncome, deductions):
    
#   Taxable income is AGI minus deductions

    if adjGrossIncome < deductions:
        taxableIncome = 0
    else:
        taxableIncome = adjGrossIncome - deductions
   
    return taxableIncome
    

def CalcTax(fileStatus, taxableIncome):
    """
    Function to do the tax calculation. Depends on 2 datapoints: Filing status and taxable income.

    Calculations are done based on tax brackets and percentage for each bracket. A different bracket
    exists for each filing status.

    These tuples are constants with the tax brackets for 4 different
    filing statuses. These would need to be updated each year.

    These numbers are current for 2022 tax brackets as of 3/14/2022
    """
    SINGLE_TAX_BRACKETS = (0, 10275, 41775, 89075, 170050, 215950, 539900)
    MARRIED_JOINT_TAX_BRACKETS = (0, 20550, 83550, 178150, 340100, 431900, 647850)
    MARRIED_SEP_TAX_BRACKETS = (0, 10275, 41775, 89075, 170050, 215950, 323925)
    HEAD_HHOLD_TAX_BRACKETS = (0, 14650, 55900, 89050, 170050, 215950, 539900)

    #  2 dimensional tuple for standrd deductions- current for tax year 2022
    STD_DEDUCTION = (("Single", 12950),("MarriedSep", 12950), ("MarriedJoint", 25900), ("HeadHouse", 19400))

    #  Tax bracket percentages current for tax year 2022
    TAX_BRCK_PCT = (10, 12, 22, 24, 32, 35, 37)

    # determine how many levels there are by looking at the percentage tuple
    numLevels = len(TAX_BRCK_PCT)

    # set searachable bracket variable to the appropriate bracket depending on filing status

    if fileStatus == "Single":
        searchBracket = SINGLE_TAX_BRACKETS
    elif fileStatus == "Married-Joint":
        searchBracket = MARRIED_JOINT_TAX_BRACKETS
    elif fileStatus == "Married-Sep":
        searchBracket = MARRIED_SEP_TAX_BRACKETS
    elif fileStatus == "Head House":
        searchBracket = HEAD_HHOLD_TAX_BRACKETS

    # income list is used to store amounts that are to be taxed at each level; first
    # initialize the entire list to 0
    income =[]
    for level in range(numLevels):
        income.append(0)

    # starting at top bracket, work down until you find the highest bracket level and store the 
    # amount to be tasked at that level;  because we have a 0th entry, range goes to -1
    for level in range(numLevels-1, -1, -1):

        if taxableIncome >= searchBracket[level]:
            income[level] = taxableIncome - searchBracket[level]
            highestLevel = level
            break

    # continue down the income list and fill in the remaining amounts per level

    for level in range(highestLevel-1,-1,-1):

        income[level] = searchBracket[level +1] - searchBracket[level]

    # compute the total tax by multiplying income for each level by the percent for that level
    # then add to the total
    
    totTax = 0
    for level in range(highestLevel+1):
        totTax += round((income[level] * TAX_BRCK_PCT[level] / 100),0)

    return totTax

def ClearValues():
    EnableItemized()
    entWages.delete(0, END)
    entIntDiv.delete(0, END)
    entSocSec.delete(0, END)
    entRetire.delete(0, END)
    entIRAAdj.delete(0, END)
    entRetireAdj.delete(0, END)
    entTaxWH.delete(0, END)
    entTaxPd.delete(0, END)
    entMedExp.delete(0, END)
    entGiftChar.delete(0, END)
    entIntPd.delete(0, END)
    seniorTax.set(0)
    blindTax.set(0)
    seniorSpouse.set(0)
    blindSpouse.set(0)
    DisableItemized()
    
    return True
    
#                ========================================
#        Main window set up
#  
mainWindow = tk.Tk()
mainWindow.title("Federal Tax Estimator Tool")
mainWindow.geometry('650x700')
mainWindow.resizable(width=False, height=False)

#  Frame set up----------------------
frmStatus = tk.LabelFrame(mainWindow, text="Filing Status (REQUIRED)", padx=10, pady=10)
frmInc = tk.LabelFrame(mainWindow, text="Income entries", padx=10, pady=5)

frmItem = tk.LabelFrame(mainWindow, text="Itemized deductions", padx=10, pady=10)
frmButtons = tk.LabelFrame(mainWindow, text="", bd=0, padx=0, pady=10)
frmImage = tk.LabelFrame(mainWindow, text="", bd=0, padx=0, pady=10)

frmStatus.grid(row=0, column = 0, padx=10,pady=10)
frmInc.grid(row=1, column = 0, padx=100,pady=10)

frmItem.grid(row=2, column = 0, padx=10, pady=10)
frmButtons.grid(row=1, column = 1, pady = 50)
frmImage.grid(row=2, column = 1, pady = 50)

# Radio button set up----------------
fStat = StringVar()
fStat.set(" ")

rbStatussi = tk.Radiobutton(frmStatus, text = "Single", variable = fStat, value ="Single")
rbStatusmj = tk.Radiobutton(frmStatus, text = "Married/Joint", variable = fStat, value ="Married-Joint")
rbStatusms = tk.Radiobutton(frmStatus, text = "Married/Separate", variable = fStat, value ="Married-Sep")
rbStatushh = tk.Radiobutton(frmStatus, text = "Head of Household", variable = fStat, value ="Head House")

rbStatussi.grid(row=0, column=0, sticky = "NW")
rbStatusmj.grid(row=1, column=0, sticky = "NW")
rbStatusms.grid(row=1, column=1, sticky = "NW")
rbStatushh.grid(row=0, column=1, sticky = "NW")

# Income labels--------------------
lblHeader = tk.Label(frmInc,text="ESTIMATED INCOME")
lblWages = tk.Label(frmInc, text = "    Wages:")
lblIntDiv = tk.Label(frmInc, text = "    Interest/Dividends:")
lblSocSec = tk.Label(frmInc, text = "    Social security:")
lblRetire = tk.Label(frmInc, text = "    Retirement:")

lblHeader.grid(row=1, column = 0, sticky = "NW")
lblWages.grid(row=2, column = 0, sticky = "NW")
lblIntDiv.grid(row=3, column = 0, sticky = "NW")
lblSocSec.grid(row=4, column = 0, sticky = "NW")
lblRetire.grid(row=5, column = 0, sticky = "NW")

#  Income entry fiels-------------------------
entWages = tk.Entry(frmInc)
entIntDiv = tk.Entry(frmInc)
entSocSec = tk.Entry(frmInc)
entRetire = tk.Entry(frmInc)

entWages.grid(row=2, column =1, sticky="NSEW")
entIntDiv.grid(row=3, column =1, sticky="NSEW")
entSocSec.grid(row=4, column =1, sticky="NSEW")
entRetire.grid(row=5, column =1, sticky="NSEW")

# Adjustment labels---------------------------
lblHeader2 = tk.Label(frmInc,text="ADJUSTMENTS TO INCOME")
lblIRAAdj = tk.Label(frmInc, text = "    IRA contribution:")
lblRetireAdj = tk.Label(frmInc, text = "    401K contribution:")

lblHeader2.grid(row=6, column = 0, sticky = "NW")
lblIRAAdj.grid(row=7, column = 0, sticky = "NW")
lblRetireAdj.grid(row=8, column = 0, sticky = "NW")


#  Adjustments entry fiels------------------
entIRAAdj = tk.Entry(frmInc,text="")
entRetireAdj = tk.Entry(frmInc,text="")

entIRAAdj.grid(row=7, column =1, sticky="NSEW")
entRetireAdj.grid(row=8, column =1, sticky="NSEW")

# Taxes w/held label and entry
lblTaxWH = tk.Label(frmInc,text="TAXES WITHHELD:")
lblTaxWH.grid(row=9, column = 0, pady = 15,sticky = "NW")
entTaxWH = tk.Entry(frmInc,text="")
entTaxWH.grid(row=9, column =1, pady = 15, sticky="NSEW")

# Special situations checkboxes----------------
lblHeader3 = tk.Label(frmInc,text="SPECIAL SITUATIONS")
lblHeader3.grid(row=10, column = 0, sticky = "NW")

seniorTax = IntVar()
chkSeniorTax = tk.Checkbutton(frmInc,text="Taxpayer is 65 or older", variable=seniorTax)
chkSeniorTax.grid(row=11, column = 0, padx =15, sticky = "NW")

blindTax = IntVar()
chkBlindTax = tk.Checkbutton(frmInc,text="Taxpayer is blind", variable=blindTax)
chkBlindTax.grid(row=11, column = 1,sticky = "NW")

seniorSpouse = IntVar()
chkSeniorSpouse = tk.Checkbutton(frmInc,text="Spouse is 65 or older", variable=seniorSpouse)
chkSeniorSpouse.grid(row=12, column = 0, padx =15, sticky = "NW")

blindSpouse = IntVar()
chkBlindSpouse = tk.Checkbutton(frmInc,text="Spouse is blind", variable=blindSpouse)
chkBlindSpouse.grid(row=12, column = 1,sticky = "NW")

btnEnterItemized = tk.Button(frmItem,text="Enter itemized deudctions", command =EnterItemized)
btnEnterItemized.grid(row=0, column=0)

# Itemized deductions labels--------------------------

lblTaxPd = tk.Label(frmItem, text = "Taxes paid:")
lblMedExp = tk.Label(frmItem, text = "Medical expenses:")
lblGiftChar = tk.Label(frmItem, text = " Gifts to charity:")
lblIntPd = tk.Label(frmItem, text = "Interest paid:")

lblTaxPd.grid(row=2, column = 0, padx=15, pady=10, sticky = "NW")
lblMedExp.grid(row=3, column = 0, padx=15,sticky = "NW")
lblGiftChar.grid(row=4, column = 0, padx=15, sticky ="NW")
lblIntPd.grid(row=5, column = 0, padx=15, sticky = "NW")

#  Itemized deductions entry fiels-------------------
entTaxPd = tk.Entry(frmItem,text="", state=DISABLED)
entMedExp = tk.Entry(frmItem,text="", state=DISABLED)
entGiftChar = tk.Entry(frmItem,text="", state=DISABLED)
entIntPd = tk.Entry(frmItem,text="", state=DISABLED)

entTaxPd.grid(row=2, column =1, pady=10, sticky="NSEW")
entMedExp.grid(row=3, column =1, sticky="NSEW")
entGiftChar.grid(row=4, column =1, sticky="NSEW")
entIntPd.grid(row=5, column =1, sticky="NSEW")

#  Buttons frame and entries-------------------
image1=tk.PhotoImage(file="tax1.gif")
image2=tk.PhotoImage(file="dollars.gif")

lblPicture1=tk.Label(frmButtons, image=image1)
lblPicture1.grid(row=0, column=0)
btnCalcTax = tk.Button(frmButtons,text="Calculate Est Tax", command=ProcessInput)
btnCalcTax.grid(row=1, column=0, pady = 20, sticky = "W")

btnClear = tk.Button(frmButtons,text="Clear all values", command=ClearValues)
btnClear.grid(row=2, column=0, pady = 20, sticky="W")

lblPicture2=tk.Label(frmImage, image=image2)
lblPicture2.grid(row=0, column=0)

mainWindow.mainloop()

